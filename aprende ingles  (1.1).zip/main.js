function toggleSubmenu(submenuId) {
    const submenu = document.getElementById(submenuId);
    if (submenu.classList.contains('hidden')) {
        submenu.classList.remove('hidden');
    } else {
        submenu.classList.add('hidden');
    }
}
